// import React from 'react'
//
// const StockRow = ({data}) => {
//     return (
//             <tr style={{textAlign:"center"}}>
//                 <td>{data.id}</td>
//                 <td>{data.item.name}</td>
//                 <td>{data.item.price}</td>
//                 <td>{data.quantity}</td>
//             </tr>
//
//     )
// }
//
// export default StockRow;