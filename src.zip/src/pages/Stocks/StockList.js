import BootstrapTable from "react-bootstrap-table-next";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {faInfo, faEdit, faTrash, faPlus} from "@fortawesome/free-solid-svg-icons";
import { Container, Button, Row, Col } from "reactstrap";
import { Link } from "react-router-dom";
import { connect } from "react-redux";
import React, { useEffect } from "react";
import { getAll, removeById } from "../../action/stockAction";
import ContainerError from "../../components/Containers";
import { Search } from "react-bootstrap-table2-toolkit";
import swal from 'sweetalert';


const { SearchBar } = Search

//Mengurutkan berdasarkan id(ada di Sort table with bootstrap 4)
const defaultSorted = [
  {
    dataField: "id",
    order: "asc",
  },
];

function StockList({ isLoading, stocks, getAll, removeById, isRemoved, error, StockRow }) {
  useEffect(() => {
    //action
    getAll();
  }, []);

  useEffect(() => {
    if (isRemoved) {
      getAll();
    }
  }, [isRemoved]);

  const onDelete = (id) => {
    swal({
      title: "Apakah Anda yakin menghapus data ini?",
      icon: "warning",
      buttons: true,
      dangerMode: true,
    })
        .then(willDelete => {
          if (willDelete) {
            removeById(id);
            swal("Data stocks Sukses dihapus", {
              icon: "success"
            });
          } else {
            swal("Data Gagal dihapus")
          }
        });
  }
  const onReload = () => {
    getAll();
  };

  useEffect(onReload, []);

  const columns = [
    {
      dataField: "id",
      text: "ID",
      sort: true,
      headerStyle: () => {
        return { textAlign: "center" };
      },
    },
    {
      dataField: "quantity",
      text: "Quantity",
      sort: true,
      headerStyle: () => {
        return { textAlign: "center" };
      },
    },
    {
      dataField: "link",
      text: "Action",
      headerStyle: () => {
        return { textAlign: "center" };
      },
      formatter: (rowContent, row) => {
        return (
            <div style={{textAlign:"center"}}>
              <Link to={"/detailStock/"+ row.id}>
                <Button color="dark" className="mt-2">
                  <FontAwesomeIcon icon={faInfo} />
                  Detail
                </Button>{" "}
                {"    "}
              </Link>

              <Link to={"/stock/"+ row.id +"/edit"}>
                <Button color="dark" className="mt-2">
                  <FontAwesomeIcon icon={faEdit} />
                  Edit
                </Button>{" "}
                {"     "}
              </Link>

              <Button color="dark" className="mt-2" onClick={() => onDelete(row.id)}>
                <FontAwesomeIcon icon={faTrash} />
                Delete
              </Button>
            </div>
        );
      },
    },
  ];

  return (
      <ContainerError error={error}>
        <Container>
          <div style={{fontFamily:"cursive"}}>
            <h1 style={{textAlign:"center"}}> STOCK LIST</h1>
          </div>
          <Row>
            <Col>
              <Link to='/stock'>
                <Button color="dark" className="mt-2">
                  <FontAwesomeIcon icon={faPlus} />
                  Create
                </Button>
              </Link>
            </Col>

            <Col>
              <div className="float-right">
                <SearchBar {...stocks.searchProps} placeholder="Search ..." />
                <br /> <br />
              </div>
            </Col>
          </Row>
          <BootstrapTable keyField="id" data={stocks} onDelete={(value)=>onDelete(value)} columns={columns} rowStyle={{textAlign:"center"}}/>
        </Container>
      </ContainerError>
  );
}

const mapStateToProps = (state) => {
  return {
    //manggil dari reducer (mengambil state)
    isRemoved: state.removeStockById.data,
    stocks: state.getStocks.data || [],
    isLoading: state.getStocks.loading || state.removeStockById.loading,
    error: state.getStocks.error || state.removeStockById,
  };
};

//Mengirimkan action
const mapDispatchToProps = { getAll, removeById };

export default connect(mapStateToProps, mapDispatchToProps)(StockList);
