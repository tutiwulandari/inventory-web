import BootstrapTable from "react-bootstrap-table-next";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {faInfo, faEdit, faTrash, faPlus, faSpinner} from "@fortawesome/free-solid-svg-icons";
import { Container, Button, Row, Col , Spinner} from "reactstrap";
import { Link } from "react-router-dom";
import { connect } from "react-redux";
import React, { useEffect } from "react";
import { findAll, removeById } from "../../action/unitAction";
import ContainerError from "../../components/Containers";
import ToolkitProvider, { Search } from 'react-bootstrap-table2-toolkit';
import paginationFactory from 'react-bootstrap-table2-paginator';
import swal from 'sweetalert';


const { SearchBar } = Search

//Mengurutkan berdasarkan id(ada di Sort table with bootstrap 4)
const defaultSorted = [
  {
    dataField: "id",
    order: "asc",
  },
];

function UnitList({ isLoading, units, findAll, removeById, isRemoved, error }) {
  useEffect(() => {
    //action
    findAll();
  }, []);

  useEffect(() => {
    if (isRemoved) {
      findAll();
    }
  }, [isRemoved]);

  const onDelete = (id) => {
    swal({
      title: "Apakah Anda yakin menghapus data ini?",
      icon: "warning",
      buttons: true,
      dangerMode: true,
    })
        .then(willDelete => {
          if (willDelete) {
            removeById(id);
            swal("Data Unit Sukses dihapus", {
              icon: "success"
            });
          } else {
            swal("Data Gagal dihapus")
          }
        });
  }
  const onReload = () => {
    findAll();
  };

  useEffect(onReload, []);

  const columns = [
    {
      dataField: "id",
      text: "ID",
      sort: true,
      headerStyle: () => {
        return { textAlign: "center" };
      },
    },
    {
      dataField: "code",
      text: "Code",
      sort: true,
      headerStyle: () => {
        return { textAlign: "center" };
      },
    },
    {
      dataField: "description",
      text: "Description",
      sort: true,
      headerStyle: () => {
        return { textAlign: "center" };
      },
    },
    {
      dataField: "link",
      text: "Action",
      headerStyle: () => {
        return { textAlign: "center" };
      },
      formatter: (rowContent, row) => {
        return (
            <div style={{textAlign:"center"}}>
              <Link to={"/unit/"+ row.id +"/edit"}>
                <Button color="dark" className="mt-2">
                  <FontAwesomeIcon icon={faEdit} />
                  Edit
                </Button>{" "}
                {"     "}
              </Link>

              <Button color="dark" className="mt-2" onClick={() => onDelete(row.id)}>
                <FontAwesomeIcon icon={faTrash} />
                Delete
              </Button>
            </div>
        );
      },
    },
  ];

  return (
      <ContainerError error={error}>
        <Container>
          <div style={{fontFamily:"cursive"}}>
            <h1 style={{textAlign:"center"}}> UNIT LIST</h1>
          </div>
          { !isLoading ? (
          <ToolkitProvider
              bootstrap4
              keyField="id"
              data= {units}
              columns={columns}
              defaultSorted={defaultSorted}
              search
          >
            {(units) => (
                <div>
                  <Row>
                    <Col>
                      <Link to="/unit">
                        <Button color="dark" className="mr-2">
                          <FontAwesomeIcon icon={faPlus} />
                          Create
                        </Button>
                        <br/> <br/>
                      </Link>
                    </Col>
                    <Col>
                      <div className="float-right">
                        <SearchBar {...units.searchProps} placeholder="Search .." />
                      </div>
                      <br/> <br/>
                    </Col>
                  </Row>
                  <BootstrapTable {...units.baseProps} pagination={ paginationFactory(units.page)} rowStyle={{textAlign:"center"}}
                  />
                </div>
            )}
          </ToolkitProvider>
            ) : (
            <div className="text-center">
          {units.error ? (
            <h4>{units.error}</h4>
            ) : (
            <Spinner color="dark" />
            )}
            </div>
            )}
        </Container>
      </ContainerError>
  );
}

const mapStateToProps = (state) => {
  return {
    //manggil dari reducer (mengambil state)
    isRemoved: state.removeUnitById.data,
    units: state.findAllUnit.data || [],
    isLoading: state.findAllUnit.loading || state.removeUnitById.loading,
    error: state.findAllUnit.error || state.removeUnitById,
  };
};

//Mengirimkan action
const mapDispatchToProps = { findAll, removeById };

export default connect(mapStateToProps, mapDispatchToProps)(UnitList);
