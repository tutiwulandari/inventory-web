import React from 'react';
import {Table} from "reactstrap";
import {Link} from "react-router-dom";

const UnitRow = ( {data} ) => {
    return (
        <Link to= '/detail/id'>
        <Table striped>
            <tbody>
            <tr>
                <td width="200">Code</td>
                <td width="10">:</td>
                <td>{data.code}</td>
            </tr>
            <tr>
                <td width="200">Description</td>
                <td width="10">:</td>
                <td>{data.description}</td>
            </tr>
            </tbody>
        </Table>
            </Link>
    );
}
export default UnitRow;
