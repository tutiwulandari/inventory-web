export default function Error() {
    return (
        <div>
            Page Not Found!
        </div>
    )
}