import {Form, FormGroup, Label, Input, Button, Container} from "reactstrap";
import {Link, useParams, useHistory, Redirect} from "react-router-dom";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {faArrowLeft} from "@fortawesome/free-solid-svg-icons";
import React, {useEffect, useState} from 'react'
import {getItemById, save} from "../../action/itemAction";
import {connect} from "react-redux";
import ContainerError from "../../components/Containers";
import {findAll} from "../../action/unitAction"

const ItemForm = ({isLoading, item,findAll, savedItem, getItemById, save, error, units}) => {
    const {id} = useParams();
    const [redirect, setRedirect] = useState(false);
    const [data, setData] = useState({})
    const history = useHistory();

    useEffect(() => {
        findAll()
    }, [findAll])

    const onReload = (id) => {
        getItemById(Number(id))
        findAll()
    }

    useEffect(() => {
        if(id) {
            onReload(id)
        }
    }, [id, getItemById])


    useEffect(() => {
        if(id) {
            getItemById(id)
        }
    }, [id, getItemById])


    useEffect(() => {
        if(id && item ) {
            setData({
                ...item
            })
        }
    }, [id, item])


    useEffect(() => {
        if (savedItem) {
            history.push('/items');
        }
    }, [savedItem, history])
    //setiap ada perubahan saveUnit dan history useEffect dijalankan

    const onSubmit = (event) => {
        event.preventDefault();
        save(data)
    }


    if (redirect === true) {
        return <Redirect to="/items" />
    }

    return (
        <ContainerError error={error} >
            <Container>
            <div>
                <Link to="/items">
                    <Button style={{marginTop: "10px"}} color="dark">
                        <FontAwesomeIcon icon={faArrowLeft}/>
                        Back
                    </Button>
                    <br/> <br/>
                </Link>
            </div>

            <div style={{width: "50%"}}>
                {
                    !isLoading ? units &&
                    <Form onSubmit={onSubmit}>
                        <FormGroup>
                            <Label htmlFor="name" sm={5} size="lg">Product Name</Label>
                            <Input type="text" name="name" bsSize="lg"
                                   id="name" placeholder="input product name"
                            value={data.name || ''} onChange= {event => setData({...data, name:event.target.value})}/>
                        </FormGroup>

                        <FormGroup>
                            <Label htmlFor="price" sm={5} size="lg">Price</Label>
                            <Input type="text" name="price" bsSize="lg" id="price" placeholder="input price"
                                   value={data.price || ''} onChange={event => setData({...data, price:event.target.value})}/>
                        </FormGroup>
                        <FormGroup>
                            <Label for ="unit"> Unit ID </Label>
                            <Input type="select" name="unit" onChange={event => setData({...data, unitId: event.target.value})}>
                                <option>-- Choose --</option>
                                {units.map((element, index) => {
                                    return (<option key={index} value={element.id}> {element.description}</option>)
                                })}
                            </Input>
                        </FormGroup><br/>
                        <FormGroup>
                            <Button color="dark">
                                {id > 0 ? "Update" : "Save"} </Button> {'   '}
                            <Button color="dark" onClick={onReload}> Reload</Button>
                        </FormGroup>
                    </Form> :
                    <p> Loading...</p>
                }
            </div>
            </Container>
        </ContainerError>

    );
}

const mapStateToProps = (state) => {
        return {
            //call reducer
            item: state.getItemById.data || [],
            isLoading: state.getItemById.isLoading || state.saveItem.loading,
            units: state.findAllUnit.data || [],
            savedItem: state.saveItem.data,
            error: state.getItemById.error || state.saveItem.error,
            update: state.updateItem,
        }
    }

const mapDispatchToProps = {getItemById, save, findAll}

export default connect(mapStateToProps, mapDispatchToProps)(ItemForm);