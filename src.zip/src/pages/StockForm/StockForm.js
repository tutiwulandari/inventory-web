import {Form, FormGroup, Label, Input, Button, Container} from "reactstrap";
import {Link, useParams, useHistory, Redirect} from "react-router-dom";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {faArrowLeft} from "@fortawesome/free-solid-svg-icons";
import React, {useEffect, useState} from 'react'
import {getStockById, save} from "../../action/stockAction";
import {connect} from "react-redux";
import ContainerError from "../../components/Containers";
import {getAll, getItemById} from "../../action/itemAction";


const StockForm = ({isLoading, stock, savedStock, getStockById, save, error, getAll, items}) => {
    const {id} = useParams();
    const [redirect, setRedirect] = useState(false);
    const [data, setData] = useState({})
    const history = useHistory();

    useEffect(() => {
        //itemAction
        getAll()
    }, [getAll])

    const onReload =(id) => {
        getStockById(Number(id))
        getAll();
    }

    useEffect(() => {
        if(id) {
            onReload(id)
        }
    }, [id, getStockById])

    useEffect(() => {
        if(id) {
            getItemById(id)
        }
    },[id, getItemById()])

    useEffect(() => {
        if(id && stock) {
            setData({
                ...stock
            })
        }
     }, [id, items])

    //Save
    useEffect(() => {
        if (savedStock) {
            history.push('/stocks');
        }
    }, [savedStock, history])


    const handleSubmit = (event) => {
        event.preventDefault();
        save(data);
    }

    if (redirect === true) {
        return <Redirect to='/stocks'/>
    }

    return (
        <ContainerError error={error} >
            <Container>
            <div>
                <Link to="/stocks">
                    <Button style={{marginTop: "10px"}} color="dark">
                        <FontAwesomeIcon icon={faArrowLeft}/>
                        Back
                    </Button>
                    <br/> <br/>
                </Link>
            </div>

            <div style={{width: "50%"}}>
                {!isLoading ? items &&
                    <Form onSubmit={handleSubmit}>
                        <FormGroup>
                            <Label for="stock" sm={5} size="lg"> Item ID</Label>
                            <Input type="select" name="unit" onChange={event => setData({...data, itemId: event.target.value})}>
                            <option>--Choose --</option>
                            {items.map((element, index) => {
                                return(<option key={index} value={element.id}>{element.name}</option> )
                            })}
                            </Input>
                        </FormGroup>
                        <FormGroup>
                            <Label htmlFor="quantity" sm={5} size="lg"> Quantity</Label>
                            <Input type="text" name="quantity" bsSize="lg" id="quantity" placeholder="input quantity product"
                                   value={data.quantity || ''} onChange={event => setData({...data, quantity: event.target.value})}/>
                        </FormGroup> <br/>
                        <FormGroup>
                            <Button color="dark"> {id > 0 ? "Update" : "Save"}</Button> {'  '}
                            <Button color="dark" onClick={onReload}>Reload</Button>
                        </FormGroup>
                    </Form> :
                    <p> Loading...</p>
                }
            </div>
            </Container>
        </ContainerError>
    );
}

const mapStateToProps = (state) => {
    return {
        //call reducer
        stock: state.getStockById.data || [],
        isLoading: state.getStockById.isLoading || state.saveStock.loading,
        items : state.getItems.data || [],
        savedStock: state.saveStock.data,
        error: state.getStockById.error || state.saveStock.error,
        update: state.updateStock
    }
}

const mapDispatchToProps = {getStockById, save, getAll}

export default connect(mapStateToProps, mapDispatchToProps)(StockForm);