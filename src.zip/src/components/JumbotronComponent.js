import React from 'react';
import { Jumbotron, Button, Container } from 'reactstrap';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCoffee } from '@fortawesome/free-solid-svg-icons';


const JumbotronComponent = (props) => {
    return (
        <div>
            <Jumbotron>
                <Container>
                    <h1 className="display-3">Hi Enigmanians!</h1>
                    <p className="lead">Make it work, make it right, make it fast.”.</p>
                    <hr className="my-2" />
                    <p>First, solve the problem. Then, write the code.</p>
                    <p className="lead">
                        <Button color="primary"><FontAwesomeIcon icon={faCoffee}/>Learn More</Button>
                    </p>
                </Container>
            </Jumbotron>
        </div>
    );
};


export default JumbotronComponent;